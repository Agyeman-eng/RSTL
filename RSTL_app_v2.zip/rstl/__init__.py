"""RSTL profitability toolkit."""
